import '@shopify/ui-extensions/preact';
import { render } from 'preact';

export default function extension() {
    render(<Extension />, document.body);
}

function Extension() {
    return (
        <s-block-stack gap="base">
            <s-heading>Club Colours Process</s-heading>
            <s-text>
                Continue to the customer bridge page.
            </s-text>
            <s-button href="https://www.wearcolours.com/pages/customer-bridge">
                Open page
            </s-button>
        </s-block-stack>
    );
}